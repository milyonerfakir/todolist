/**
 * ETK Project Management
 * Main JavaScript file
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initTooltips();
    
    // Initialize dropdowns
    initDropdowns();
    
    // Initialize flash message dismissal
    initFlashMessages();
    
    // Initialize mobile menu
    initMobileMenu();
});

/**
 * Initialize tooltips
 */
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseenter', function() {
            const text = this.getAttribute('data-tooltip');
            const tooltipEl = document.createElement('div');
            tooltipEl.className = 'absolute z-50 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded shadow-lg';
            tooltipEl.textContent = text;
            tooltipEl.style.bottom = 'calc(100% + 5px)';
            tooltipEl.style.left = '50%';
            tooltipEl.style.transform = 'translateX(-50%)';
            tooltipEl.style.whiteSpace = 'nowrap';
            
            this.style.position = 'relative';
            this.appendChild(tooltipEl);
        });
        
        tooltip.addEventListener('mouseleave', function() {
            const tooltipEl = this.querySelector('div');
            if (tooltipEl) {
                tooltipEl.remove();
            }
        });
    });
}

/**
 * Initialize dropdowns
 */
function initDropdowns() {
    const dropdowns = document.querySelectorAll('[data-dropdown]');
    
    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('[data-dropdown-trigger]');
        const menu = dropdown.querySelector('[data-dropdown-menu]');
        
        if (trigger && menu) {
            trigger.addEventListener('click', function(e) {
                e.stopPropagation();
                menu.classList.toggle('hidden');
            });
            
            document.addEventListener('click', function(e) {
                if (!dropdown.contains(e.target)) {
                    menu.classList.add('hidden');
                }
            });
        }
    });
}

/**
 * Initialize flash message dismissal
 */
function initFlashMessages() {
    const flashMessages = document.querySelectorAll('[role="alert"]');
    
    flashMessages.forEach(message => {
        // Add dismiss button
        const dismissBtn = document.createElement('button');
        dismissBtn.className = 'ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex h-8 w-8';
        dismissBtn.innerHTML = '<span class="sr-only">Dismiss</span><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>';
        
        // Add flex container for message content and dismiss button
        const flexContainer = document.createElement('div');
        flexContainer.className = 'flex items-center';
        
        // Move message content to flex container
        const messageContent = message.innerHTML;
        message.innerHTML = '';
        
        // Create paragraph for message content
        const messageParagraph = document.createElement('div');
        messageParagraph.innerHTML = messageContent;
        
        // Append elements
        flexContainer.appendChild(messageParagraph);
        flexContainer.appendChild(dismissBtn);
        message.appendChild(flexContainer);
        
        // Add dismiss functionality
        dismissBtn.addEventListener('click', function() {
            message.remove();
        });
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            message.classList.add('opacity-0', 'transition-opacity', 'duration-500');
            setTimeout(() => {
                message.remove();
            }, 500);
        }, 5000);
    });
}

/**
 * Initialize mobile menu
 */
function initMobileMenu() {
    const mobileMenuButton = document.querySelector('[data-mobile-menu-button]');
    const mobileMenu = document.querySelector('[data-mobile-menu]');
    
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
}

/**
 * Format date to YYYY-MM-DD
 * 
 * @param {Date} date 
 * @returns {string}
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
}

/**
 * Format date and time to YYYY-MM-DD HH:MM:SS
 * 
 * @param {Date} date 
 * @returns {string}
 */
function formatDateTime(date) {
    const formattedDate = formatDate(date);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    
    return `${formattedDate} ${hours}:${minutes}:${seconds}`;
}

/**
 * Format a number as a percentage
 * 
 * @param {number} value 
 * @param {number} total 
 * @returns {string}
 */
function formatPercentage(value, total) {
    if (total === 0) return '0%';
    
    const percentage = (value / total) * 100;
    return `${Math.round(percentage)}%`;
}

/**
 * Make an AJAX request
 * 
 * @param {string} url 
 * @param {string} method 
 * @param {object} data 
 * @param {function} callback 
 */
function ajax(url, method, data, callback) {
    const xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            let response;
            try {
                response = JSON.parse(xhr.responseText);
            } catch (e) {
                response = xhr.responseText;
            }
            callback(null, response);
        } else {
            callback(xhr.statusText, null);
        }
    };
    
    xhr.onerror = function() {
        callback('Network error', null);
    };
    
    xhr.send(data ? JSON.stringify(data) : null);
}