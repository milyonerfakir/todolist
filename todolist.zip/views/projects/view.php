<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4"><?= htmlspecialchars($project['name']) ?></h1>
    <p class="mb-4"><?= htmlspecialchars($project['description']) ?></p>

    <h2 class="text-xl font-semibold mt-6 mb-2">Takım Üyeleri</h2>
    <ul class="list-disc pl-5">
        <?php foreach ($teamMembers as $member): ?>
            <li><?= htmlspecialchars($member['name']) ?></li>
        <?php endforeach; ?>
    </ul>

    <h2 class="text-xl font-semibold mt-6 mb-2">Görevler</h2>
    <ul class="space-y-2">
        <?php foreach ($tasks as $task): ?>
            <li class="p-2 bg-gray-100 rounded"><?= htmlspecialchars($task['title']) ?> - <?= htmlspecialchars($task['status']) ?></li>
        <?php endforeach; ?>
    </ul>
</div>
