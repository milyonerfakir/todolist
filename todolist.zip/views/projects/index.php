<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Projeler</h1>
    <?php if (!empty($projects)): ?>
        <ul class="space-y-2">
            <?php foreach ($projects as $project): ?>
                <li class="p-4 bg-white shadow rounded">
                    <strong><?= htmlspecialchars($project['name']) ?></strong> - <?= htmlspecialchars($project['description']) ?>
                    <div>
                        <a href="/projects/view/<?= $project['id'] ?>" class="text-blue-600 hover:underline text-sm">Görüntüle</a>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Hiç proje bulunamadı.</p>
    <?php endif; ?>
</div>
