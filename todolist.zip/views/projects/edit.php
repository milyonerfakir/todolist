<div class="container mx-auto mt-10 max-w-xl">
    <h1 class="text-2xl font-bold mb-4">Proje Düzenle</h1>
    <form action="/projects/update/<?= $project['id'] ?>" method="POST" class="space-y-4">
        <input type="text" name="name" value="<?= htmlspecialchars($project['name']) ?>" class="w-full border px-4 py-2 rounded" required>
        <textarea name="description" class="w-full border px-4 py-2 rounded" required><?= htmlspecialchars($project['description']) ?></textarea>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Güncelle</button>
    </form>
</div>
