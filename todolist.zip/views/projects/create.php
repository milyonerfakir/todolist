<div class="container mx-auto mt-10 max-w-xl">
    <h1 class="text-2xl font-bold mb-4">Yeni Proje Oluştur</h1>
    <form action="/projects/store" method="POST" class="space-y-4">
        <input type="text" name="name" placeholder="Proje Adı" class="w-full border px-4 py-2 rounded" required>
        <textarea name="description" placeholder="Proje Açıklaması" class="w-full border px-4 py-2 rounded" required></textarea>
        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Oluştur</button>
    </form>
</div>
