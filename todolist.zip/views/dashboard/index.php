<div class="container mx-auto px-4 py-8">
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
        <div class="mt-4 md:mt-0">
            <a href="/tasks/create" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg inline-flex items-center">
                <i class="fas fa-plus mr-2"></i> New Task
            </a>
            <a href="/projects/create" class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg inline-flex items-center ml-2">
                <i class="fas fa-folder-plus mr-2"></i> New Project
            </a>
        </div>
    </div>

    <!-- Task Statistics -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-tasks text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">Total Tasks</p>
                    <p class="text-2xl font-semibold text-gray-800"><?= $taskStats['total'] ?></p>
                </div>
            </div>
            <div class="mt-4">
                <div class="w-full bg-gray-200 rounded-full h-2.5">
                    <div class="bg-blue-600 h-2.5 rounded-full" style="width: <?= ($taskStats['done'] / max(1, $taskStats['total'])) * 100 ?>%"></div>
                </div>
                <p class="text-xs text-gray-500 mt-1"><?= $taskStats['done'] ?> of <?= $taskStats['total'] ?> tasks completed</p>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-spinner text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">In Progress</p>
                    <p class="text-2xl font-semibold text-gray-800"><?= $taskStats['in_progress'] ?></p>
                </div>
            </div>
            <div class="mt-4">
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Status</span>
                    <span class="font-medium"><?= round(($taskStats['in_progress'] / max(1, $taskStats['total'])) * 100) ?>%</span>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-check-circle text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">Completed</p>
                    <p class="text-2xl font-semibold text-gray-800"><?= $taskStats['done'] ?></p>
                </div>
            </div>
            <div class="mt-4">
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Status</span>
                    <span class="font-medium"><?= round(($taskStats['done'] / max(1, $taskStats['total'])) * 100) ?>%</span>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-red-100 text-red-600">
                    <i class="fas fa-exclamation-circle text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">Overdue</p>
                    <p class="text-2xl font-semibold text-gray-800"><?= $taskStats['overdue'] ?></p>
                </div>
            </div>
            <div class="mt-4">
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Status</span>
                    <span class="font-medium"><?= round(($taskStats['overdue'] / max(1, $taskStats['total'])) * 100) ?>%</span>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Recent Projects -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-800">Recent Projects</h2>
                </div>
                <div class="p-6">
                    <?php if (empty($recentProjects)): ?>
                        <p class="text-gray-500 text-center py-4">No projects found.</p>
                    <?php else: ?>
                        <div class="space-y-4">
                            <?php foreach ($recentProjects as $project): ?>
                                <div class="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <a href="/projects/view/<?= $project['id'] ?>" class="text-blue-600 hover:text-blue-800 font-medium"><?= $project['name'] ?></a>
                                            <p class="text-sm text-gray-500 mt-1"><?= $project['task_count'] ?> tasks</p>
                                        </div>
                                        <div class="bg-gray-100 rounded-full px-3 py-1 text-xs font-medium text-gray-800">
                                            <?= ucfirst($project['status']) ?>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <div class="w-full bg-gray-200 rounded-full h-1.5">
                                            <?php $progress = $project['task_count'] > 0 ? ($project['completed_tasks'] / $project['task_count']) * 100 : 0; ?>
                                            <div class="bg-blue-600 h-1.5 rounded-full" style="width: <?= $progress ?>%"></div>
                                        </div>
                                        <p class="text-xs text-gray-500 mt-1"><?= $project['completed_tasks'] ?> of <?= $project['task_count'] ?> tasks completed</p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-4 text-center">
                            <a href="/projects" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View all projects</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Upcoming Tasks -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-800">Upcoming Tasks</h2>
                </div>
                <div class="p-6">
                    <?php if (empty($upcomingTasks)): ?>
                        <p class="text-gray-500 text-center py-4">No upcoming tasks.</p>
                    <?php else: ?>
                        <div class="space-y-4">
                            <?php foreach ($upcomingTasks as $task): ?>
                                <div class="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <a href="/tasks/view/<?= $task['id'] ?>" class="text-blue-600 hover:text-blue-800 font-medium"><?= $task['title'] ?></a>
                                            <p class="text-sm text-gray-500 mt-1"><?= $task['project_name'] ?></p>
                                        </div>
                                        <?php
                                            $priorityColors = [
                                                'low' => 'bg-green-100 text-green-800',
                                                'medium' => 'bg-yellow-100 text-yellow-800',
                                                'high' => 'bg-red-100 text-red-800'
                                            ];
                                            $priorityColor = $priorityColors[$task['priority']] ?? 'bg-gray-100 text-gray-800';
                                        ?>
                                        <div class="<?= $priorityColor ?> rounded-full px-3 py-1 text-xs font-medium">
                                            <?= ucfirst($task['priority']) ?>
                                        </div>
                                    </div>
                                    <div class="mt-2 flex items-center text-sm text-gray-500">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <span>Due: <?= date('M j, Y', strtotime($task['due_date'])) ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-4 text-center">
                            <a href="/tasks" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View all tasks</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Overdue Tasks -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-800">Overdue Tasks</h2>
                </div>
                <div class="p-6">
                    <?php if (empty($overdueTasks)): ?>
                        <p class="text-gray-500 text-center py-4">No overdue tasks. Great job!</p>
                    <?php else: ?>
                        <div class="space-y-4">
                            <?php foreach ($overdueTasks as $task): ?>
                                <div class="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <a href="/tasks/view/<?= $task['id'] ?>" class="text-blue-600 hover:text-blue-800 font-medium"><?= $task['title'] ?></a>
                                            <p class="text-sm text-gray-500 mt-1"><?= $task['project_name'] ?></p>
                                        </div>
                                        <div class="bg-red-100 text-red-800 rounded-full px-3 py-1 text-xs font-medium">
                                            Overdue
                                        </div>
                                    </div>
                                    <div class="mt-2 flex items-center text-sm text-red-500">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <span>Due: <?= date('M j, Y', strtotime($task['due_date'])) ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-4 text-center">
                            <a href="/tasks" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View all tasks</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>