<div class="container mx-auto mt-10 max-w-xl">
    <h1 class="text-2xl font-bold mb-4">Gelişmiş Arama</h1>
    <form action="/search/advanced-search" method="POST" class="space-y-4">
        <input type="text" name="keyword" placeholder="Anahtar kelime" class="w-full border px-4 py-2 rounded" required>
        
        <select name="project_id" class="w-full border px-4 py-2 rounded">
            <option value="">Tüm Projeler</option>
            <?php foreach ($projects as $project): ?>
                <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <input type="date" name="start_date" class="w-full border px-4 py-2 rounded">
        <input type="date" name="end_date" class="w-full border px-4 py-2 rounded">

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Ara</button>
    </form>
</div>
