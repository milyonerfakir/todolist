<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Arama Sonuçları</h1>
    <p class="mb-4">Aranan: <strong><?= htmlspecialchars($query) ?></strong> (<?= htmlspecialchars($type) ?>)</p>

    <?php if (empty($results)): ?>
        <p>Sonuç bulunamadı.</p>
    <?php else: ?>
        <?php if ($type === 'all'): ?>
            <h2 class="text-xl font-semibold mt-4">Görevler</h2>
            <ul>
                <?php foreach ($results['tasks'] as $task): ?>
                    <li><?= htmlspecialchars($task['title']) ?></li>
                <?php endforeach; ?>
            </ul>

            <h2 class="text-xl font-semibold mt-4">Projeler</h2>
            <ul>
                <?php foreach ($results['projects'] as $project): ?>
                    <li><?= htmlspecialchars($project['name']) ?></li>
                <?php endforeach; ?>
            </ul>

            <h2 class="text-xl font-semibold mt-4">Kullanıcılar</h2>
            <ul>
                <?php foreach ($results['users'] as $user): ?>
                    <li><?= htmlspecialchars($user['name']) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <ul>
                <?php foreach ($results as $item): ?>
                    <li><?= htmlspecialchars($item['title'] ?? $item['name']) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    <?php endif; ?>
</div>
