<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Gelişmiş Arama Sonuçları</h1>

    <?php if (empty($results)): ?>
        <p>Sonuç bulunamadı.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($results as $task): ?>
                <li><?= htmlspecialchars($task['title']) ?> - <?= htmlspecialchars($task['status']) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
