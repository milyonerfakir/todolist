<?php
// Eğer $content değişkeni tanımlanmamışsa, boş bir değer atayalım
if (!isset($content)) {
    $content = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETK Project Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="/css/app.css">
    <?php if (isset($extraStyles)): ?>
        <?php foreach ($extraStyles as $style): ?>
            <link rel="stylesheet" href="<?= $style ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">

    <?php if (isset($_SESSION['user'])): ?>
    <header class="bg-white shadow">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center">
                <a href="/" class="text-xl font-bold text-blue-600">
                    <i class="fas fa-tasks mr-2"></i>
                    ETK Project
                </a>
            </div>
            <div class="flex items-center space-x-4">
                <form action="/search" method="GET" class="hidden md:block">
                    <div class="relative">
                        <input type="text" name="q" placeholder="Search..." class="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <div class="absolute left-3 top-2.5 text-gray-400">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                </form>
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="flex items-center focus:outline-none">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user']['name']) ?>&background=3B82F6&color=fff" alt="Profile" class="w-8 h-8 rounded-full">
                        <span class="ml-2 hidden md:inline"><?= $_SESSION['user']['name'] ?></span>
                        <i class="fas fa-chevron-down ml-1 text-xs"></i>
                    </button>
                    <div x-show="open" @click.away="open = false" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                        <a href="/profile" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                        <a href="/settings" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
                        <div class="border-t border-gray-100"></div>
                        <a href="/logout" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-blue-600">
            <div class="container mx-auto px-4">
                <nav class="flex overflow-x-auto">
                    <a href="/dashboard" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= $_SERVER['REQUEST_URI'] === '/dashboard' || $_SERVER['REQUEST_URI'] === '/' ? 'border-b-2 border-white' : '' ?>">Dashboard</a>
                    <a href="/projects" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/projects') === 0 ? 'border-b-2 border-white' : '' ?>">Projects</a>
                    <a href="/tasks" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/tasks') === 0 && strpos($_SERVER['REQUEST_URI'], '/tasks/kanban') !== 0 && strpos($_SERVER['REQUEST_URI'], '/tasks/gantt') !== 0 ? 'border-b-2 border-white' : '' ?>">Tasks</a>
                    <a href="/tasks/kanban" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/tasks/kanban') === 0 ? 'border-b-2 border-white' : '' ?>">Kanban</a>
                    <a href="/tasks/gantt" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/tasks/gantt') === 0 ? 'border-b-2 border-white' : '' ?>">Gantt</a>
                    <a href="/calendar" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/calendar') === 0 ? 'border-b-2 border-white' : '' ?>">Calendar</a>
                    <a href="/reports" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/reports') === 0 ? 'border-b-2 border-white' : '' ?>">Reports</a>
                    <a href="/security" class="px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 <?= strpos($_SERVER['REQUEST_URI'], '/security') === 0 ? 'border-b-2 border-white' : '' ?>">Security</a>
                </nav>
            </div>
        </div>
    </header>
    <?php endif; ?>

    <main class="flex-grow">
        <?php if (isset($_SESSION['_flash']['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4 container mx-auto mt-4" role="alert">
                <p><?= $_SESSION['_flash']['success'] ?></p>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['_flash']['error'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 container mx-auto mt-4" role="alert">
                <p><?= $_SESSION['_flash']['error'] ?></p>
            </div>
        <?php endif; ?>

        {{content}}
    </main>

    <footer class="bg-white shadow mt-auto">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div>
                    <p class="text-sm text-gray-600">&copy; <?= date('Y') ?> ETK Project Management. All rights reserved.</p>
                </div>
                <div>
                    <a href="#" class="text-sm text-gray-600 hover:text-blue-600">Terms</a>
                    <span class="mx-2 text-gray-400">|</span>
                    <a href="#" class="text-sm text-gray-600 hover:text-blue-600">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <script src="/js/app.js"></script>
    <?php if (isset($extraScripts)): ?>
        <?php foreach ($extraScripts as $script): ?>
            <script src="<?= $script ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>