<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Kullanıcı Üretkenlik Raporu</h1>
    <p><?= htmlspecialchars($startDate) ?> - <?= htmlspecialchars($endDate) ?> arası</p>

    <table class="w-full mt-6 border">
        <thead>
            <tr class="bg-gray-100">
                <th class="p-2 border">Kullanıcı</th>
                <th class="p-2 border">Tamamlanan Görev</th>
                <th class="p-2 border">Oluşturulan Görev</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td class="p-2 border"><?= htmlspecialchars($user['name']) ?></td>
                    <td class="p-2 border"><?= $user['tasksCompleted'] ?></td>
                    <td class="p-2 border"><?= $user['tasksCreated'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
