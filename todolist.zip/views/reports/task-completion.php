<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Görev Tamamlanma Raporu</h1>
    <p><?= htmlspecialchars($startDate) ?> - <?= htmlspecialchars($endDate) ?> arası görev tamamlama verileri:</p>

    <?php if (!empty($data)): ?>
        <ul class="mt-4 space-y-2">
            <?php foreach ($data as $entry): ?>
                <li><?= htmlspecialchars($entry['date']) ?> - <?= $entry['completed_count'] ?> görev tamamlandı</li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Veri bulunamadı.</p>
    <?php endif; ?>
</div>
