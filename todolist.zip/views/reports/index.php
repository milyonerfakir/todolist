<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-6">Raporlar</h1>
    <ul class="space-y-4">
        <li><a href="/reports/task-completion" class="text-blue-600 hover:underline">Görev Tamamlanma Raporu</a></li>
        <li><a href="/reports/project-progress" class="text-blue-600 hover:underline">Proje İlerleme Raporu</a></li>
        <li><a href="/reports/user-productivity" class="text-blue-600 hover:underline">Kullanıcı Üretkenlik Raporu</a></li>
    </ul>
</div>
