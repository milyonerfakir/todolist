<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Proje İlerleme Raporu</h1>

    <?php if (!empty($projects)): ?>
        <ul class="space-y-4">
            <?php foreach ($projects as $project): ?>
                <li class="p-4 bg-white shadow rounded">
                    <strong><?= htmlspecialchars($project['name']) ?></strong><br>
                    İlerleme: %<?= $project['progress'] ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Proje bulunamadı.</p>
    <?php endif; ?>
</div>
