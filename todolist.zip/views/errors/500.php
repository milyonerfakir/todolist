<div class="min-h-screen flex flex-col items-center justify-center bg-gray-100">
    <div class="text-center">
        <h1 class="text-9xl font-bold text-red-600">500</h1>
        <h2 class="text-4xl font-bold text-gray-800 mt-4">Server Error</h2>
        <p class="text-gray-600 mt-4 max-w-md mx-auto">Sorry, something went wrong on our servers. We're working to fix the issue as soon as possible.</p>
        <div class="mt-8">
            <a href="/" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg inline-flex items-center">
                <i class="fas fa-home mr-2"></i> Go to Homepage
            </a>
        </div>
    </div>
</div>