<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">Güvenlik Ayarları</h1>

    <ul class="space-y-4">
        <li>
            <a href="/security/change-password" class="text-blue-600 hover:underline">
                Şifre Değiştir
            </a>
        </li>
        <li>
            <a href="/security/two-factor" class="text-blue-600 hover:underline">
                İki Faktörlü Kimlik Doğrulama
            </a>
        </li>
    </ul>
</div>
