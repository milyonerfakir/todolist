<div class="container mx-auto mt-10 max-w-xl">
    <h1 class="text-2xl font-bold mb-4">İki Faktörlü Kimlik Doğrulama</h1>

    <?php if ($twoFactorEnabled): ?>
        <p class="mb-4 text-green-700">İki faktörlü kimlik doğrulama etkin.</p>
        <form method="POST" action="/security/disable-two-factor">
            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded">Devre Dışı Bırak</button>
        </form>
    <?php else: ?>
        <p class="mb-4 text-yellow-700">Henüz etkin değil. Aşağıdaki QR kodu tarayarak etkinleştirebilirsiniz.</p>
        <?php if ($qrCodeUrl): ?>
            <img src="<?= $qrCodeUrl ?>" alt="QR Kod" class="mb-4">
        <?php endif; ?>
        <form method="POST" action="/security/enable-two-factor" class="space-y-4">
            <input type="hidden" name="secret_key" value="<?= htmlspecialchars($secretKey) ?>">
            <input type="text" name="verification_code" placeholder="Doğrulama Kodu" class="w-full border px-4 py-2 rounded" required>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Etkinleştir</button>
        </form>
    <?php endif; ?>
</div>
