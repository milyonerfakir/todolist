<div class="container mx-auto mt-10 max-w-md">
    <h1 class="text-2xl font-bold mb-4">Şifre Değiştir</h1>

    <form method="POST" action="/security/update-password" class="space-y-4">
        <input type="password" name="current_password" placeholder="Mevcut Şifre" class="w-full border px-4 py-2 rounded" required>
        <input type="password" name="new_password" placeholder="Yeni Şifre" class="w-full border px-4 py-2 rounded" required>
        <input type="password" name="confirm_password" placeholder="Yeni Şifre (Tekrar)" class="w-full border px-4 py-2 rounded" required>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Güncelle</button>
    </form>
</div>
