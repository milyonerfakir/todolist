<?php

/**
 * ETK Project Management
 *
 * @package  ETK
 * @author   ETK Team
 */

use App\Controllers\Api\LanguageController;

$router = App\Core\Application::getInstance()->getRouter();

// API Routes
$router->get('/api/tasks', function($request, $response) {
    $tasks = (new App\Models\Task())->getAll();
    return $response->jsonResponse($tasks);
});

$router->get('/api/tasks/gantt', function($request, $response) {
    $tasks = (new App\Models\Task())->getAllForGantt();
    return $response->jsonResponse($tasks);
});

$router->post('/api/tasks/update-position', function($request, $response) {
    $data = $request->json();
    $result = (new App\Models\Task())->updatePosition($data['id'], $data['status'], $data['position']);
    return $response->jsonResponse(['success' => $result]);
});

$router->get('/api/projects', function($request, $response) {
    $projects = (new App\Models\Project())->getAll();
    return $response->jsonResponse($projects);
});

$router->get('/api/calendar/events', function($request, $response) {
    $events = (new App\Models\Calendar())->getEvents();
    return $response->jsonResponse($events);
});

$router->post('/api/calendar/events/move', function($request, $response) {
    $data = $request->json();
    $result = (new App\Models\Calendar())->moveEvent($data['id'], $data['start'], $data['end']);
    return $response->jsonResponse(['success' => $result]);
});

$router->get('/api/search', function($request, $response) {
    $query = $request->input('q');
    $results = (new App\Models\Search())->search($query);
    return $response->jsonResponse($results);
});

$router->get('/api/security', function($request, $response) {
    $logs = (new App\Models\SecurityLog())->getRecent();
    return $response->jsonResponse($logs);
});

$router->get('/api/bulk', function($request, $response) {
    $operations = (new App\Models\BulkOperation())->getAvailable();
    return $response->jsonResponse($operations);
});

$router->get('/api/columns/index', function($request, $response) {
    $columns = [
        ['id' => 'todo', 'title' => 'To Do'],
        ['id' => 'in_progress', 'title' => 'In Progress'],
        ['id' => 'review', 'title' => 'Review'],
        ['id' => 'done', 'title' => 'Done']
    ];
    return $response->jsonResponse($columns);
});

// Language API
$router->get('/api/languages', [LanguageController::class, 'getLanguages']);
$router->get('/api/language/current', [LanguageController::class, 'getCurrentLanguage']);
$router->post('/api/language/set', [LanguageController::class, 'setLanguage']);