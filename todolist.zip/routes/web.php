<?php

/**
 * ETK Project Management
 *
 * @package  ETK
 * @author   ETK Team
 */

use App\Controllers\AuthController;
use App\Controllers\DashboardController;
use App\Controllers\ProjectController;
use App\Controllers\TaskController;
use App\Controllers\CalendarController;
use App\Controllers\ReportController;
use App\Controllers\SecurityController;
use App\Controllers\SearchController;
use App\Controllers\BulkOperationController;

$router = App\Core\Application::getInstance()->getRouter();

// Authentication Routes
$router->get('/login', [AuthController::class, 'loginView']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'registerView']);
$router->post('/register', [AuthController::class, 'register']);
$router->get('/logout', [AuthController::class, 'logout']);

// Dashboard Routes
$router->get('/', [DashboardController::class, 'index']);
$router->get('/dashboard', [DashboardController::class, 'index']);

// Project Routes
$router->get('/projects', [ProjectController::class, 'index']);
$router->get('/projects/create', [ProjectController::class, 'create']);
$router->post('/projects/store', [ProjectController::class, 'store']);
$router->get('/projects/edit/{id}', [ProjectController::class, 'edit']);
$router->post('/projects/update/{id}', [ProjectController::class, 'update']);
$router->get('/projects/delete/{id}', [ProjectController::class, 'delete']);
$router->get('/projects/view/{id}', [ProjectController::class, 'view']);

// Task Routes
$router->get('/tasks', [TaskController::class, 'index']);
$router->get('/tasks/create', [TaskController::class, 'create']);
$router->post('/tasks/store', [TaskController::class, 'store']);
$router->get('/tasks/edit/{id}', [TaskController::class, 'edit']);
$router->post('/tasks/update/{id}', [TaskController::class, 'update']);
$router->get('/tasks/delete/{id}', [TaskController::class, 'delete']);
$router->get('/tasks/view/{id}', [TaskController::class, 'view']);
$router->get('/tasks/kanban', [TaskController::class, 'kanban']);
$router->get('/tasks/gantt', [TaskController::class, 'gantt']);

// Calendar Routes
$router->get('/calendar', [CalendarController::class, 'index']);
$router->post('/calendar/events', [CalendarController::class, 'events']);
$router->post('/calendar/event/create', [CalendarController::class, 'createEvent']);
$router->post('/calendar/event/update', [CalendarController::class, 'updateEvent']);
$router->post('/calendar/event/delete', [CalendarController::class, 'deleteEvent']);

// Report Routes
$router->get('/reports', [ReportController::class, 'index']);
$router->get('/reports/create', [ReportController::class, 'create']);
$router->post('/reports/store', [ReportController::class, 'store']);
$router->get('/reports/edit/{id}', [ReportController::class, 'edit']);
$router->post('/reports/update/{id}', [ReportController::class, 'update']);
$router->get('/reports/delete/{id}', [ReportController::class, 'delete']);
$router->get('/reports/view/{id}', [ReportController::class, 'view']);
$router->get('/reports/generate/{id}', [ReportController::class, 'generate']);
$router->get('/reports/download/{id}', [ReportController::class, 'download']);

// Security Routes
$router->get('/security', [SecurityController::class, 'index']);
$router->post('/security/update', [SecurityController::class, 'update']);

// Search Routes
$router->get('/search', [SearchController::class, 'index']);
$router->post('/search/results', [SearchController::class, 'results']);

// Bulk Operation Routes
$router->get('/bulk', [BulkOperationController::class, 'index']);
$router->post('/bulk/process', [BulkOperationController::class, 'process']);