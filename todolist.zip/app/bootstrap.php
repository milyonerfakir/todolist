<?php

/**
 * ETK Project Management
 *
 * @package  ETK
 * @author   ETK Team
 */

/*
|--------------------------------------------------------------------------
| Register The Auto Loader
|--------------------------------------------------------------------------
|
| Composer provides a convenient, automatically generated class loader for
| our application. We just need to utilize it! We'll simply require it
| into the script here so that we don't have to worry about manual
| loading any of our classes later on. It feels great to relax.
|
*/

require __DIR__.'/../vendor/autoload.php';

/*
|--------------------------------------------------------------------------
| Load Environment Variables
|--------------------------------------------------------------------------
|
| Here we will load the environment variables from the .env file if one exists.
| This is useful for local development and testing.
|
*/

if (file_exists(__DIR__.'/../.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__.'/..');
    $dotenv->load();
}

/*
|--------------------------------------------------------------------------
| Set Error Reporting
|--------------------------------------------------------------------------
|
| Here we will set the error reporting level based on the environment.
| In production, we'll set it to hide all errors, while in development
| we'll show all errors to help with debugging.
|
*/

if (getenv('APP_ENV') === 'production') {
    error_reporting(0);
    ini_set('display_errors', 0);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

/*
|--------------------------------------------------------------------------
| Set Default Timezone
|--------------------------------------------------------------------------
|
| Here we will set the default timezone for the application.
|
*/

date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'UTC');

/*
|--------------------------------------------------------------------------
| Start Session
|--------------------------------------------------------------------------
|
| Start the session for the application.
|
*/

session_start();