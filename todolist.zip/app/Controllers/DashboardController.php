<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Project;
use App\Models\Task;

class DashboardController extends Controller
{
    /**
     * Show the dashboard.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $projectModel = new Project();
        $taskModel = new Task();
        
        // Get recent projects
        $recentProjects = $projectModel->getRecent($user['id'], 5);
        
        // Get task statistics
        $taskStats = $taskModel->getStatistics($user['id']);
        
        // Get upcoming tasks
        $upcomingTasks = $taskModel->getUpcoming($user['id'], 5);
        
        // Get overdue tasks
        $overdueTasks = $taskModel->getOverdue($user['id']);
        
        return $response->view('dashboard/index', [
            'user' => $user,
            'recentProjects' => $recentProjects,
            'taskStats' => $taskStats,
            'upcomingTasks' => $upcomingTasks,
            'overdueTasks' => $overdueTasks,
        ]);
    }
}