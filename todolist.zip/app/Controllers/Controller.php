<?php

namespace App\Controllers;

use App\Core\Session;
use App\Core\Response;

class Controller
{
    /**
     * Kullanıcı oturumu yoksa giriş ekranına yönlendir.
     */
    protected function requireAuth(Response $response)
    {
        if (!Session::has('user')) {
            $_SESSION['_flash']['error'] = 'Bu sayfayı görüntülemek için giriş yapmalısınız.';
            $response->redirect('/login');
        }
    }

    /**
     * Giriş yapmış kullanıcıyı döndür.
     */
    protected function getUser()
    {
        return Session::get('user');
    }

    /**
     * Kullanıcının oturumda olup olmadığını kontrol et.
     */
    protected function isAuthenticated()
    {
        return Session::has('user');
    }

    /**
     * Kullanıcının admin olup olmadığını kontrol et.
     */
    protected function isAdmin()
    {
        if (!$this->isAuthenticated()) {
            return false;
        }

        $user = $this->getUser();
        return $user['role'] === 'admin';
    }
}
