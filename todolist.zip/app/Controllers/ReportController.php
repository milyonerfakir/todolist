<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Task;
use App\Models\Project;
use App\Models\User;

class ReportController extends Controller
{
    /**
     * Show the reports dashboard.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        $projectModel = new Project();
        
        // Görev istatistikleri
        $taskStats = $taskModel->getStatistics($user['id']);
        
        // Proje istatistikleri
        $projectStats = $projectModel->getStatistics($user['id']);
        
        return $response->view('reports/index', [
            'taskStats' => $taskStats,
            'projectStats' => $projectStats
        ]);
    }
    
    /**
     * Show task completion report.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function taskCompletion(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        
        $startDate = $request->get('start_date', date('Y-m-d', strtotime('-30 days')));
        $endDate = $request->get('end_date', date('Y-m-d'));
        
        $data = $taskModel->getCompletionData($user['id'], $startDate, $endDate);
        
        return $response->view('reports/task-completion', [
            'data' => $data,
            'startDate' => $startDate,
            'endDate' => $endDate
        ]);
    }
    
    /**
     * Show project progress report.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function projectProgress(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $projectModel = new Project();
        
        $projects = $projectModel->getAll($user['id']);
        $projectData = [];
        
        foreach ($projects as $project) {
            $projectData[] = [
                'id' => $project['id'],
                'name' => $project['name'],
                'progress' => $projectModel->calculateProgress($project['id'])
            ];
        }
        
        return $response->view('reports/project-progress', [
            'projects' => $projectData
        ]);
    }
    
    /**
     * Show user productivity report.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function userProductivity(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        $userModel = new User();
        
        $startDate = $request->get('start_date', date('Y-m-d', strtotime('-30 days')));
        $endDate = $request->get('end_date', date('Y-m-d'));
        
        $users = $userModel->getAll();
        $userData = [];
        
        foreach ($users as $u) {
            $userData[] = [
                'id' => $u['id'],
                'name' => $u['name'],
                'tasksCompleted' => $taskModel->getCompletedCount($u['id'], $startDate, $endDate),
                'tasksCreated' => $taskModel->getCreatedCount($u['id'], $startDate, $endDate)
            ];
        }
        
        return $response->view('reports/user-productivity', [
            'users' => $userData,
            'startDate' => $startDate,
            'endDate' => $endDate
        ]);
    }
    
    /**
     * Export report as CSV.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function exportCsv(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $reportType = $params['type'] ?? 'tasks';
        $user = Session::get('user');
        
        switch ($reportType) {
            case 'tasks':
                $taskModel = new Task();
                $data = $taskModel->getAll($user['id']);
                $headers = ['ID', 'Başlık', 'Açıklama', 'Durum', 'Öncelik', 'Başlangıç Tarihi', 'Bitiş Tarihi'];
                $filename = 'tasks_report_' . date('Y-m-d') . '.csv';
                break;
                
            case 'projects':
                $projectModel = new Project();
                $data = $projectModel->getAll($user['id']);
                $headers = ['ID', 'Ad', 'Açıklama', 'Başlangıç Tarihi', 'Bitiş Tarihi', 'Durum'];
                $filename = 'projects_report_' . date('Y-m-d') . '.csv';
                break;
                
            default:
                Session::setFlash('error', 'Geçersiz rapor türü');
                return $response->redirect('/reports');
        }
        
        // CSV dosyası oluştur
        $output = fopen('php://temp', 'r+');
        fputcsv($output, $headers);
        
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        
        // CSV dosyasını indir
        $response->setHeader('Content-Type', 'text/csv');
        $response->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"');
        $response->setHeader('Pragma', 'no-cache');
        $response->setHeader('Expires', '0');
        
        return $response->setContent($csv);
    }
}