<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\User;

class SecurityController extends Controller
{
    /**
     * Show the security dashboard.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        
        return $response->view('security/index', [
            'user' => $user
        ]);
    }
    
    /**
     * Show the change password form.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function changePassword(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        return $response->view('security/change-password');
    }
    
    /**
     * Update the user's password.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function updatePassword(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $data = $request->all();
        
        // Mevcut şifreyi doğrula
        $userModel = new User();
        $isValid = $userModel->verifyPassword($user['id'], $data['current_password']);
        
        if (!$isValid) {
            Session::setFlash('error', 'Mevcut şifre yanlış');
            return $response->redirect('/security/change-password');
        }
        
        // Yeni şifrelerin eşleştiğini kontrol et
        if ($data['new_password'] !== $data['confirm_password']) {
            Session::setFlash('error', 'Yeni şifreler eşleşmiyor');
            return $response->redirect('/security/change-password');
        }
        
        // Şifreyi güncelle
        $result = $userModel->updatePassword($user['id'], $data['new_password']);
        
        if ($result) {
            Session::setFlash('success', 'Şifreniz başarıyla güncellendi');
            return $response->redirect('/security');
        }
        
        Session::setFlash('error', 'Şifre güncellenemedi');
        return $response->redirect('/security/change-password');
    }
    
    /**
     * Show the two-factor authentication setup page.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function twoFactor(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $userModel = new User();
        
        $twoFactorEnabled = $userModel->isTwoFactorEnabled($user['id']);
        $secretKey = $twoFactorEnabled ? null : $this->generateSecretKey();
        
        if (!$twoFactorEnabled && $secretKey) {
            // QR kod için gerekli bilgileri hazırla
            $qrCodeUrl = $this->generateQrCodeUrl($user['email'], $secretKey);
        }
        
        return $response->view('security/two-factor', [
            'twoFactorEnabled' => $twoFactorEnabled,
            'secretKey' => $secretKey ?? null,
            'qrCodeUrl' => $qrCodeUrl ?? null
        ]);
    }
    
    /**
     * Enable two-factor authentication.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function enableTwoFactor(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $data = $request->all();
        
        // Doğrulama kodunu kontrol et
        $secretKey = $data['secret_key'];
        $verificationCode = $data['verification_code'];
        
        if (!$this->verifyCode($secretKey, $verificationCode)) {
            Session::setFlash('error', 'Doğrulama kodu geçersiz');
            return $response->redirect('/security/two-factor');
        }
        
        // İki faktörlü kimlik doğrulamayı etkinleştir
        $userModel = new User();
        $result = $userModel->enableTwoFactor($user['id'], $secretKey);
        
        if ($result) {
            Session::setFlash('success', 'İki faktörlü kimlik doğrulama etkinleştirildi');
        } else {
            Session::setFlash('error', 'İki faktörlü kimlik doğrulama etkinleştirilemedi');
        }
        
        return $response->redirect('/security');
    }
    
    /**
     * Disable two-factor authentication.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function disableTwoFactor(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $userModel = new User();
        
        $result = $userModel->disableTwoFactor($user['id']);
        
        if ($result) {
            Session::setFlash('success', 'İki faktörlü kimlik doğrulama devre dışı bırakıldı');
        } else {
            Session::setFlash('error', 'İki faktörlü kimlik doğrulama devre dışı bırakılamadı');
        }
        
        return $response->redirect('/security');
    }
    
    /**
     * Generate a secret key for two-factor authentication.
     *
     * @return string
     */
    private function generateSecretKey()
    {
        // Basit bir rastgele anahtar oluştur (gerçek uygulamada daha güvenli bir yöntem kullanılmalı)
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = '';
        
        for ($i = 0; $i < 16; $i++) {
            $secret .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        return $secret;
    }
    
    /**
     * Generate a QR code URL for two-factor authentication.
     *
     * @param string $email
     * @param string $secretKey
     * @return string
     */
    private function generateQrCodeUrl($email, $secretKey)
    {
        $appName = 'ETK Project';
        $url = "otpauth://totp/" . urlencode($appName) . ":" . urlencode($email) . "?secret=" . $secretKey . "&issuer=" . urlencode($appName);
        
        // Google Chart API kullanarak QR kod URL'si oluştur
        return "https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=" . urlencode($url);
    }
    
    /**
     * Verify a two-factor authentication code.
     *
     * @param string $secretKey
     * @param string $code
     * @return bool
     */
    private function verifyCode($secretKey, $code)
    {
        // Basit bir doğrulama (gerçek uygulamada TOTP algoritması kullanılmalı)
        // Bu örnek sadece gösterim amaçlıdır
        return strlen($code) === 6 && is_numeric($code);
    }
}