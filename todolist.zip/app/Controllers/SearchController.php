<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Task;
use App\Models\Project;
use App\Models\User;

class SearchController extends Controller
{
    /**
     * Search for tasks, projects, and users.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $query = $request->get('q', '');
        $type = $request->get('type', 'all');
        
        if (empty($query)) {
            return $response->view('search/index', [
                'query' => '',
                'type' => $type,
                'results' => []
            ]);
        }
        
        $user = Session::get('user');
        $results = [];
        
        // Arama türüne göre filtreleme
        switch ($type) {
            case 'tasks':
                $results = $this->searchTasks($query, $user['id']);
                break;
                
            case 'projects':
                $results = $this->searchProjects($query, $user['id']);
                break;
                
            case 'users':
                $results = $this->searchUsers($query);
                break;
                
            default:
                // Tüm kategorilerde arama
                $results = [
                    'tasks' => $this->searchTasks($query, $user['id']),
                    'projects' => $this->searchProjects($query, $user['id']),
                    'users' => $this->searchUsers($query)
                ];
                break;
        }
        
        return $response->view('search/index', [
            'query' => $query,
            'type' => $type,
            'results' => $results
        ]);
    }
    
    /**
     * Search for tasks.
     *
     * @param string $query
     * @param int $userId
     * @return array
     */
    private function searchTasks($query, $userId)
    {
        $taskModel = new Task();
        return $taskModel->search($query, $userId);
    }
    
    /**
     * Search for projects.
     *
     * @param string $query
     * @param int $userId
     * @return array
     */
    private function searchProjects($query, $userId)
    {
        $projectModel = new Project();
        return $projectModel->search($query, $userId);
    }
    
    /**
     * Search for users.
     *
     * @param string $query
     * @return array
     */
    private function searchUsers($query)
    {
        $userModel = new User();
        return $userModel->search($query);
    }
    
    /**
     * Advanced search form.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function advanced(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $projectModel = new Project();
        $user = Session::get('user');
        $projects = $projectModel->getAll($user['id']);
        
        return $response->view('search/advanced', [
            'projects' => $projects
        ]);
    }
    
    /**
     * Perform advanced search.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function advancedSearch(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $data = $request->all();
        
        $taskModel = new Task();
        $results = $taskModel->advancedSearch($data, $user['id']);
        
        return $response->view('search/advanced-results', [
            'results' => $results,
            'criteria' => $data