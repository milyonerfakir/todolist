<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\User;

class AuthController extends Controller
{
    /**
     * Show the login view.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function loginView(Request $request, Response $response)
    {
        return $response->view('auth/login');
    }

    /**
     * Handle the login request.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function login(Request $request, Response $response)
    {
        $email = $request->input('email');
        $password = $request->input('password');
        
        // Validate input
        $errors = [];
        
        if (empty($email)) {
            $errors['email'] = 'Email is required';
        }
        
        if (empty($password)) {
            $errors['password'] = 'Password is required';
        }
        
        if (!empty($errors)) {
            Session::setFlash('errors', $errors);
            Session::setFlash('old', $request->all());
            return $response->redirect('/login');
        }
        
        // Attempt to authenticate
        $user = new User();
        $authenticated = $user->authenticate($email, $password);
        
        if (!$authenticated) {
            Session::setFlash('error', 'Invalid email or password');
            Session::setFlash('old', $request->all());
            return $response->redirect('/login');
        }
        
        // Log the user in
        Session::set('user', $authenticated);
        Session::setFlash('success', 'You have been logged in successfully');
        
        return $response->redirect('/dashboard');
    }

    /**
     * Show the registration view.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function registerView(Request $request, Response $response)
    {
        return $response->view('auth/register');
    }

    /**
     * Handle the registration request.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function register(Request $request, Response $response)
    {
        $name = $request->input('name');
        $email = $request->input('email');
        $password = $request->input('password');
        $passwordConfirmation = $request->input('password_confirmation');
        
        // Validate input
        $errors = [];
        
        if (empty($name)) {
            $errors['name'] = 'Name is required';
        }
        
        if (empty($email)) {
            $errors['email'] = 'Email is required';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email is invalid';
        }
        
        if (empty($password)) {
            $errors['password'] = 'Password is required';
        } elseif (strlen($password) < 8) {
            $errors['password'] = 'Password must be at least 8 characters';
        }
        
        if ($password !== $passwordConfirmation) {
            $errors['password_confirmation'] = 'Passwords do not match';
        }
        
        if (!empty($errors)) {
            Session::setFlash('errors', $errors);
            Session::setFlash('old', $request->all());
            return $response->redirect('/register');
        }
        
        // Check if user already exists
        $user = new User();
        $existingUser = $user->findByEmail($email);
        
        if ($existingUser) {
            Session::setFlash('error', 'Email already exists');
            Session::setFlash('old', $request->all());
            return $response->redirect('/register');
        }
        
        // Create the user
        $userId = $user->create([
            'name' => $name,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
        ]);
        
        if (!$userId) {
            Session::setFlash('error', 'Failed to create user');
            Session::setFlash('old', $request->all());
            return $response->redirect('/register');
        }
        
        // Log the user in
        $newUser = $user->find($userId);
        Session::set('user', $newUser);
        Session::setFlash('success', 'Your account has been created successfully');
        
        return $response->redirect('/dashboard');
    }

    /**
     * Handle the logout request.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function logout(Request $request, Response $response)
    {
        Session::remove('user');
        Session::setFlash('success', 'You have been logged out successfully');
        
        return $response->redirect('/login');
    }
}