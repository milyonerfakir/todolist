<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Task;
use App\Models\Project;

class TaskController extends Controller
{
    /**
     * Show all tasks.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        
        $tasks = $taskModel->getAll($user['id']);
        
        return $response->view('tasks/index', [
            'tasks' => $tasks
        ]);
    }
    
    /**
     * Show the task creation form.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function create(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $projectModel = new Project();
        $projects = $projectModel->getAll();
        
        return $response->view('tasks/create', [
            'projects' => $projects
        ]);
    }
    
    /**
     * Store a new task.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function store(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $data = $request->all();
        $data['created_by'] = $user['id'];
        
        $taskModel = new Task();
        $taskId = $taskModel->create($data);
        
        if ($taskId) {
            Session::setFlash('success', 'Task created successfully');
            return $response->redirect('/tasks');
        }
        
        Session::setFlash('error', 'Failed to create task');
        return $response->redirect('/tasks/create');
    }
    
    /**
     * Show the task edit form.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function edit(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $taskModel = new Task();
        $task = $taskModel->find($params['id']);
        
        if (!$task) {
            Session::setFlash('error', 'Task not found');
            return $response->redirect('/tasks');
        }
        
        $projectModel = new Project();
        $projects = $projectModel->getAll();
        
        return $response->view('tasks/edit', [
            'task' => $task,
            'projects' => $projects
        ]);
    }
    
    /**
     * Update a task.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function update(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $taskModel = new Task();
        $task = $taskModel->find($params['id']);
        
        if (!$task) {
            Session::setFlash('error', 'Task not found');
            return $response->redirect('/tasks');
        }
        
        $data = $request->all();
        $result = $taskModel->update($params['id'], $data);
        
        if ($result) {
            Session::setFlash('success', 'Task updated successfully');
            return $response->redirect('/tasks');
        }
        
        Session::setFlash('error', 'Failed to update task');
        return $response->redirect('/tasks/edit/' . $params['id']);
    }
    
    /**
     * Delete a task.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function delete(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $taskModel = new Task();
        $result = $taskModel->delete($params['id']);
        
        if ($result) {
            Session::setFlash('success', 'Task deleted successfully');
        } else {
            Session::setFlash('error', 'Failed to delete task');
        }
        
        return $response->redirect('/tasks');
    }
    
    /**
     * View a task.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function view(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $taskModel = new Task();
        $task = $taskModel->find($params['id']);
        
        if (!$task) {
            Session::setFlash('error', 'Task not found');
            return $response->redirect('/tasks');
        }
        
        return $response->view('tasks/view', [
            'task' => $task
        ]);
    }
    
    /**
     * Show the kanban board.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function kanban(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        
        $todoTasks = $taskModel->getByStatus('todo', $user['id']);
        $inProgressTasks = $taskModel->getByStatus('in_progress', $user['id']);
        $reviewTasks = $taskModel->getByStatus('review', $user['id']);
        $doneTasks = $taskModel->getByStatus('done', $user['id']);
        
        return $response->view('tasks/kanban', [
            'todoTasks' => $todoTasks,
            'inProgressTasks' => $inProgressTasks,
            'reviewTasks' => $reviewTasks,
            'doneTasks' => $doneTasks
        ]);
    }
    
    /**
     * Show the gantt chart.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function gantt(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        
        $tasks = $taskModel->getAllForGantt($user['id']);
        
        return $response->view('tasks/gantt', [
            'tasks' => $tasks
        ]);
    }
}