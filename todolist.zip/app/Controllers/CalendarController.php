<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Task;
use App\Models\Project;

class CalendarController extends Controller
{
    /**
     * Show the calendar.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        
        // Takvim için görevleri al
        $tasks = $taskModel->getForCalendar($user['id']);
        
        return $response->view('calendar/index', [
            'tasks' => $tasks
        ]);
    }
    
    /**
     * Get events for the calendar (AJAX).
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function events(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $taskModel = new Task();
        
        $start = $request->get('start');
        $end = $request->get('end');
        
        $tasks = $taskModel->getForCalendarRange($user['id'], $start, $end);
        
        $events = [];
        foreach ($tasks as $task) {
            $events[] = [
                'id' => $task['id'],
                'title' => $task['title'],
                'start' => $task['start_date'],
                'end' => $task['due_date'],
                'url' => '/tasks/view/' . $task['id'],
                'backgroundColor' => $this->getStatusColor($task['status']),
                'borderColor' => $this->getStatusColor($task['status']),
                'allDay' => true
            ];
        }
        
        return $response->json($events);
    }
    
    /**
     * Get color for task status.
     *
     * @param string $status
     * @return string
     */
    private function getStatusColor($status)
    {
        switch ($status) {
            case 'todo':
                return '#3490dc'; // Mavi
            case 'in_progress':
                return '#f6993f'; // Turuncu
            case 'review':
                return '#9561e2'; // Mor
            case 'done':
                return '#38c172'; // Yeşil
            default:
                return '#6c757d'; // Gri
        }
    }
    
    /**
     * Update event date (AJAX).
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function updateEvent(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $taskId = $request->get('id');
        $startDate = $request->get('start');
        $endDate = $request->get('end');
        
        $taskModel = new Task();
        $result = $taskModel->updateDates($taskId, $startDate, $endDate);
        
        return $response->json([
            'success' => $result
        ]);
    }
}