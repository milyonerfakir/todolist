<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Project;
use App\Models\Task;
use App\Models\User;

class ProjectController extends Controller
{
    /**
     * Show all projects.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function index(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $projectModel = new Project();
        
        $projects = $projectModel->getAll($user['id']);
        
        return $response->view('projects/index', [
            'projects' => $projects
        ]);
    }
    
    /**
     * Show the project creation form.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function create(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $userModel = new User();
        $users = $userModel->getAll();
        
        return $response->view('projects/create', [
            'users' => $users
        ]);
    }
    
    /**
     * Store a new project.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function store(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $user = Session::get('user');
        $data = $request->all();
        $data['created_by'] = $user['id'];
        
        $projectModel = new Project();
        $projectId = $projectModel->create($data);
        
        if ($projectId) {
            // Eğer takım üyeleri seçildiyse, onları projeye ekle
            if (isset($data['team_members']) && is_array($data['team_members'])) {
                foreach ($data['team_members'] as $memberId) {
                    $projectModel->addTeamMember($projectId, $memberId);
                }
            }
            
            Session::setFlash('success', 'Proje başarıyla oluşturuldu');
            return $response->redirect('/projects');
        }
        
        Session::setFlash('error', 'Proje oluşturulamadı');
        return $response->redirect('/projects/create');
    }
    
    /**
     * Show the project edit form.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function edit(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $projectModel = new Project();
        $project = $projectModel->find($params['id']);
        
        if (!$project) {
            Session::setFlash('error', 'Proje bulunamadı');
            return $response->redirect('/projects');
        }
        
        $userModel = new User();
        $users = $userModel->getAll();
        
        // Projenin mevcut takım üyelerini al
        $teamMembers = $projectModel->getTeamMembers($params['id']);
        
        return $response->view('projects/edit', [
            'project' => $project,
            'users' => $users,
            'teamMembers' => $teamMembers
        ]);
    }
    
    /**
     * Update a project.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function update(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $projectModel = new Project();
        $project = $projectModel->find($params['id']);
        
        if (!$project) {
            Session::setFlash('error', 'Proje bulunamadı');
            return $response->redirect('/projects');
        }
        
        $data = $request->all();
        $result = $projectModel->update($params['id'], $data);
        
        if ($result) {
            // Takım üyelerini güncelle
            $projectModel->removeAllTeamMembers($params['id']);
            
            if (isset($data['team_members']) && is_array($data['team_members'])) {
                foreach ($data['team_members'] as $memberId) {
                    $projectModel->addTeamMember($params['id'], $memberId);
                }
            }
            
            Session::setFlash('success', 'Proje başarıyla güncellendi');
            return $response->redirect('/projects');
        }
        
        Session::setFlash('error', 'Proje güncellenemedi');
        return $response->redirect('/projects/edit/' . $params['id']);
    }
    
    /**
     * Delete a project.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function delete(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $projectModel = new Project();
        $result = $projectModel->delete($params['id']);
        
        if ($result) {
            Session::setFlash('success', 'Proje başarıyla silindi');
        } else {
            Session::setFlash('error', 'Proje silinemedi');
        }
        
        return $response->redirect('/projects');
    }
    
    /**
     * View a project.
     *
     * @param Request $request
     * @param Response $response
     * @param array $params
     * @return void
     */
    public function view(Request $request, Response $response, $params)
    {
        $this->requireAuth($response);
        
        $projectModel = new Project();
        $project = $projectModel->find($params['id']);
        
        if (!$project) {
            Session::setFlash('error', 'Proje bulunamadı');
            return $response->redirect('/projects');
        }
        
        // Projenin görevlerini al
        $taskModel = new Task();
        $tasks = $taskModel->getByProject($params['id']);
        
        // Projenin takım üyelerini al
        $teamMembers = $projectModel->getTeamMembers($params['id']);
        
        return $response->view('projects/view', [
            'project' => $project,
            'tasks' => $tasks,
            'teamMembers' => $teamMembers
        ]);
    }
}