<?php

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Task;
use App\Models\Project;

class BulkOperationController extends Controller
{
    /**
     * Perform bulk operations on tasks.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function tasks(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $data = $request->all();
        $operation = $data['operation'] ?? '';
        $taskIds = $data['task_ids'] ?? [];
        
        if (empty($taskIds) || empty($operation)) {
            Session::setFlash('error', 'Geçersiz işlem veya hiçbir görev seçilmedi');
            return $response->redirect('/tasks');
        }
        
        $taskModel = new Task();
        $result = false;
        
        switch ($operation) {
            case 'delete':
                $result = $taskModel->bulkDelete($taskIds);
                $message = 'Seçilen görevler başarıyla silindi';
                break;
                
            case 'status':
                $status = $data['status'] ?? '';
                if (empty($status)) {
                    Session::setFlash('error', 'Durum seçilmedi');
                    return $response->redirect('/tasks');
                }
                $result = $taskModel->bulkUpdateStatus($taskIds, $status);
                $message = 'Seçilen görevlerin durumu güncellendi';
                break;
                
            case 'priority':
                $priority = $data['priority'] ?? '';
                if (empty($priority)) {
                    Session::setFlash('error', 'Öncelik seçilmedi');
                    return $response->redirect('/tasks');
                }
                $result = $taskModel->bulkUpdatePriority($taskIds, $priority);
                $message = 'Seçilen görevlerin önceliği güncellendi';
                break;
                
            case 'assign':
                $assigneeId = $data['assignee_id'] ?? '';
                if (empty($assigneeId)) {
                    Session::setFlash('error', 'Atanacak kullanıcı seçilmedi');
                    return $response->redirect('/tasks');
                }
                $result = $taskModel->bulkUpdateAssignee($taskIds, $assigneeId);
                $message = 'Seçilen görevler başarıyla atandı';
                break;
                
            case 'project':
                $projectId = $data['project_id'] ?? '';
                if (empty($projectId)) {
                    Session::setFlash('error', 'Proje seçilmedi');
                    return $response->redirect('/tasks');
                }
                $result = $taskModel->bulkUpdateProject($taskIds, $projectId);
                $message = 'Seçilen görevler başarıyla projeye taşındı';
                break;
                
            default:
                Session::setFlash('error', 'Geçersiz toplu işlem');
                return $response->redirect('/tasks');
        }
        
        if ($result) {
            Session::setFlash('success', $message);
        } else {
            Session::setFlash('error', 'Toplu işlem gerçekleştirilemedi');
        }
        
        return $response->redirect('/tasks');
    }
    
    /**
     * Perform bulk operations on projects.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function projects(Request $request, Response $response)
    {
        $this->requireAuth($response);
        
        $data = $request->all();
        $operation = $data['operation'] ?? '';
        $projectIds = $data['project_ids'] ?? [];
        
        if (empty($projectIds) || empty($operation)) {
            Session::setFlash('error', 'Geçersiz işlem veya hiçbir proje seçilmedi');
            return $response->redirect('/projects');
        }
        
        $projectModel = new Project();
        $result = false;
        
        switch ($operation) {
            case 'delete':
                $result = $projectModel->bulkDelete($projectIds);
                $message = 'Seçilen projeler başarıyla silindi';
                break;
                
            case 'status':
                $status = $data['status'] ?? '';
                if (empty($status)) {
                    Session::setFlash('error', 'Durum seçilmedi');
                    return $response->redirect('/projects');
                }
                $result = $projectModel->bulkUpdateStatus($projectIds, $status);
                $message = 'Seçilen projelerin durumu güncellendi';
                break;
                
            case 'archive':
                $result = $projectModel->bulkArchive($projectIds);
                $message = 'Seçilen projeler başarıyla arşivlendi';
                break;
                
            default:
                Session::setFlash('error', 'Geçersiz toplu işlem');
                return $response->redirect('/projects');
        }
        
        if ($result) {
            Session::setFlash('success', $message);
        } else {
            Session::setFlash('error', 'Toplu işlem gerçekleştirilemedi');
        }
        
        return $response->redirect('/projects');
    }
}