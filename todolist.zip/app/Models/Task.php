<?php

namespace App\Models;

use App\Core\Database;

class Task
{
    /**
     * The database instance.
     *
     * @var \App\Core\Database
     */
    protected $db;

    /**
     * Create a new Task instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Find a task by ID.
     *
     * @param int $id
     * @return array|null
     */
    public function find($id)
    {
        return $this->db->fetch("
            SELECT t.*, p.name as project_name, u.name as assigned_to_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            LEFT JOIN users u ON t.assigned_to = u.id
            WHERE t.id = ?
        ", [$id]);
    }

    /**
     * Create a new task.
     *
     * @param array $data
     * @return int|bool
     */
    public function create($data)
    {
        $sql = "INSERT INTO tasks (title, description, status, priority, project_id, assigned_to, created_by, due_date, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $params = [
            $data['title'],
            $data['description'] ?? null,
            $data['status'] ?? 'todo',
            $data['priority'] ?? 'medium',
            $data['project_id'],
            $data['assigned_to'] ?? null,
            $data['created_by'],
            $data['due_date'] ?? null,
        ];
        
        $this->db->query($sql, $params);
        return $this->db->lastInsertId();
    }

    /**
     * Update a task.
     *
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data)
    {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $fields[] = "$key = ?";
                $params[] = $value;
            }
        }
        
        $params[] = $id;
        
        $sql = "UPDATE tasks SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
        
        $this->db->query($sql, $params);
        return true;
    }

    /**
     * Delete a task.
     *
     * @param int $id
     * @return bool
     */
    public function delete($id)
    {
        $this->db->query("DELETE FROM tasks WHERE id = ?", [$id]);
        return true;
    }

    /**
     * Get all tasks.
     *
     * @param int|null $userId
     * @return array
     */
    public function getAll($userId = null)
    {
        $sql = "
            SELECT t.*, p.name as project_name, u.name as assigned_to_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            LEFT JOIN users u ON t.assigned_to = u.id
        ";
        
        $params = [];
        
        if ($userId) {
            $sql .= " WHERE t.assigned_to = ? OR t.created_by = ?";
            $params = [$userId, $userId];
        }
        
        $sql .= " ORDER BY t.due_date ASC, t.priority DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get tasks by project.
     *
     * @param int $projectId
     * @return array
     */
    public function getByProject($projectId)
    {
        return $this->db->fetchAll("
            SELECT t.*, u.name as assigned_to_name
            FROM tasks t
            LEFT JOIN users u ON t.assigned_to = u.id
            WHERE t.project_id = ?
            ORDER BY t.due_date ASC, t.priority DESC
        ", [$projectId]);
    }

    /**
     * Get tasks by status.
     *
     * @param string $status
     * @param int|null $userId
     * @return array
     */
    public function getByStatus($status, $userId = null)
    {
        $sql = "
            SELECT t.*, p.name as project_name, u.name as assigned_to_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            LEFT JOIN users u ON t.assigned_to = u.id
            WHERE t.status = ?
        ";
        
        $params = [$status];
        
        if ($userId) {
            $sql .= " AND (t.assigned_to = ? OR t.created_by = ?)";
            $params[] = $userId;
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY t.position ASC, t.due_date ASC, t.priority DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get upcoming tasks.
     *
     * @param int $userId
     * @param int $limit
     * @return array
     */
    public function getUpcoming($userId, $limit = 5)
    {
        return $this->db->fetchAll("
            SELECT t.*, p.name as project_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            WHERE (t.assigned_to = ? OR t.created_by = ?)
            AND t.status != 'done'
            AND t.due_date >= CURDATE()
            ORDER BY t.due_date ASC, t.priority DESC
            LIMIT ?
        ", [$userId, $userId, $limit]);
    }

    /**
     * Get overdue tasks.
     *
     * @param int $userId
     * @return array
     */
    public function getOverdue($userId)
    {
        return $this->db->fetchAll("
            SELECT t.*, p.name as project_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            WHERE (t.assigned_to = ? OR t.created_by = ?)
            AND t.status != 'done'
            AND t.due_date < CURDATE()
            ORDER BY t.due_date ASC, t.priority DESC
        ", [$userId, $userId]);
    }

    /**
     * Get task statistics.
     *
     * @param int $userId
     * @return array
     */
    public function getStatistics($userId)
    {
        $stats = [
            'total' => 0,
            'todo' => 0,
            'in_progress' => 0,
            'review' => 0,
            'done' => 0,
            'overdue' => 0,
        ];
        
        $result = $this->db->fetchAll("
            SELECT status, COUNT(*) as count
            FROM tasks
            WHERE (assigned_to = ? OR created_by = ?)
            GROUP BY status
        ", [$userId, $userId]);
        
        foreach ($result as $row) {
            $stats[$row['status']] = (int) $row['count'];
            $stats['total'] += (int) $row['count'];
        }
        
        $overdue = $this->db->fetch("
            SELECT COUNT(*) as count
            FROM tasks
            WHERE (assigned_to = ? OR created_by = ?)
            AND status != 'done'
            AND due_date < CURDATE()
        ", [$userId, $userId]);
        
        $stats['overdue'] = (int) $overdue['count'];
        
        return $stats;
    }

    /**
     * Update task position.
     *
     * @param int $id
     * @param string $status
     * @param int $position
     * @return bool
     */
    public function updatePosition($id, $status, $position)
    {
        // First update the task status and position
        $this->db->query("
            UPDATE tasks
            SET status = ?, position = ?, updated_at = NOW()
            WHERE id = ?
        ", [$status, $position, $id]);
        
        // Then reorder all tasks in the same status
        $tasks = $this->db->fetchAll("
            SELECT id
            FROM tasks
            WHERE status = ?
            ORDER BY position ASC, id ASC
        ", [$status]);
        
        $pos = 0;
        foreach ($tasks as $task) {
            $this->db->query("
                UPDATE tasks
                SET position = ?
                WHERE id = ?
            ", [$pos, $task['id']]);
            $pos++;
        }
        
        return true;
    }

    /**
     * Get all tasks for Gantt chart.
     *
     * @return array
     */
    public function getAllForGantt()
    {
        return $this->db->fetchAll("
            SELECT t.id, t.title, t.start_date, t.due_date as end_date, 
                   t.status, t.progress, t.project_id, t.parent_id,
                   p.name as project_name, u.name as assigned_to_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            LEFT JOIN users u ON t.assigned_to = u.id
            ORDER BY t.project_id, t.parent_id, t.id
        ");
    }
}
/**
 * Get tasks for calendar view.
 *
 * @param int $userId
 * @return array
 */
public function getForCalendar($userId)
{
    return $this->db->fetchAll("
        SELECT id, title, start_date, due_date as end_date
        FROM tasks
        WHERE (assigned_to = ? OR created_by = ?)
        AND start_date IS NOT NULL AND due_date IS NOT NULL
        ORDER BY start_date ASC
    ", [$userId, $userId]);
}
