<?php

namespace App\Models;

use App\Core\Database;

class User
{
    /**
     * The database instance.
     *
     * @var \App\Core\Database
     */
    protected $db;

    /**
     * Create a new User instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Find a user by ID.
     *
     * @param int $id
     * @return array|null
     */
    public function find($id)
    {
        return $this->db->fetch("SELECT * FROM users WHERE id = ?", [$id]);
    }

    /**
     * Find a user by email.
     *
     * @param string $email
     * @return array|null
     */
    public function findByEmail($email)
    {
        return $this->db->fetch("SELECT * FROM users WHERE email = ?", [$email]);
    }

    /**
     * Create a new user.
     *
     * @param array $data
     * @return int|bool
     */
    public function create($data)
    {
        $sql = "INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, ?, NOW())";
        $params = [
            $data['name'],
            $data['email'],
            $data['password'],
            $data['role'] ?? 'user',
        ];
        
        $this->db->query($sql, $params);
        return $this->db->lastInsertId();
    }

    /**
     * Update a user.
     *
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data)
    {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $fields[] = "$key = ?";
                $params[] = $value;
            }
        }
        
        $params[] = $id;
        
        $sql = "UPDATE users SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
        
        $this->db->query($sql, $params);
        return true;
    }

    /**
     * Delete a user.
     *
     * @param int $id
     * @return bool
     */
    public function delete($id)
    {
        $this->db->query("DELETE FROM users WHERE id = ?", [$id]);
        return true;
    }

    /**
     * Authenticate a user.
     *
     * @param string $email
     * @param string $password
     * @return array|bool
     */
    public function authenticate($email, $password)
    {
        $user = $this->findByEmail($email);
        
        if (!$user) {
            return false;
        }
        
        if (!password_verify($password, $user['password'])) {
            return false;
        }
        
        // Update last login time
        $this->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);
        
        // Remove password from user data
        unset($user['password']);
        
        return $user;
    }

    /**
     * Get all users.
     *
     * @return array
     */
    public function getAll()
    {
        return $this->db->fetchAll("SELECT id, name, email, role, created_at, updated_at, last_login FROM users ORDER BY name");
    }

    /**
     * Change a user's password.
     *
     * @param int $id
     * @param string $password
     * @return bool
     */
    public function changePassword($id, $password)
    {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        return $this->update($id, ['password' => $hashedPassword]);
    }
}