<?php

namespace App\Models;

use App\Core\Database;

class Project
{
    /**
     * The database instance.
     *
     * @var \App\Core\Database
     */
    protected $db;

    /**
     * Create a new Project instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Find a project by ID.
     *
     * @param int $id
     * @return array|null
     */
    public function find($id)
    {
        return $this->db->fetch("
            SELECT p.*, u.name as owner_name
            FROM projects p
            LEFT JOIN users u ON p.owner_id = u.id
            WHERE p.id = ?
        ", [$id]);
    }

    /**
     * Create a new project.
     *
     * @param array $data
     * @return int|bool
     */
    public function create($data)
    {
        $sql = "INSERT INTO projects (name, description, status, owner_id, start_date, end_date, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        $params = [
            $data['name'],
            $data['description'] ?? null,
            $data['status'] ?? 'active',
            $data['owner_id'],
            $data['start_date'] ?? null,
            $data['end_date'] ?? null,
        ];
        
        $this->db->query($sql, $params);
        return $this->db->lastInsertId();
    }

    /**
     * Update a project.
     *
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data)
    {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $fields[] = "$key = ?";
                $params[] = $value;
            }
        }
        
        $params[] = $id;
        
        $sql = "UPDATE projects SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
        
        $this->db->query($sql, $params);
        return true;
    }

    /**
     * Delete a project.
     *
     * @param int $id
     * @return bool
     */
    public function delete($id)
    {
        // First delete all tasks associated with this project
        $this->db->query("DELETE FROM tasks WHERE project_id = ?", [$id]);
        
        // Then delete the project
        $this->db->query("DELETE FROM projects WHERE id = ?", [$id]);
        
        return true;
    }

    /**
     * Get all projects.
     *
     * @param int|null $userId
     * @return array
     */
    public function getAll($userId = null)
    {
        $sql = "
            SELECT p.*, u.name as owner_name,
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count,
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id AND status = 'done') as completed_tasks
            FROM projects p
            LEFT JOIN users u ON p.owner_id = u.id
        ";
        
        $params = [];
        
        if ($userId) {
            $sql .= " WHERE p.owner_id = ? OR p.id IN (SELECT project_id FROM project_members WHERE user_id = ?)";
            $params = [$userId, $userId];
        }
        
        $sql .= " ORDER BY p.name";
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get recent projects.
     *
     * @param int $userId
     * @param int $limit
     * @return array
     */
    public function getRecent($userId, $limit = 5)
    {
        return $this->db->fetchAll("
            SELECT p.*, 
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count,
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id AND status = 'done') as completed_tasks
            FROM projects p
            WHERE p.owner_id = ? OR p.id IN (SELECT project_id FROM project_members WHERE user_id = ?)
            ORDER BY p.updated_at DESC
            LIMIT ?
        ", [$userId, $userId, $limit]);
    }

    /**
     * Get project members.
     *
     * @param int $projectId
     * @return array
     */
    public function getMembers($projectId)
    {
        return $this->db->fetchAll("
            SELECT u.id, u.name, u.email, pm.role
            FROM project_members pm
            JOIN users u ON pm.user_id = u.id
            WHERE pm.project_id = ?
            ORDER BY u.name
        ", [$projectId]);
    }

    /**
     * Add a member to a project.
     *
     * @param int $projectId
     * @param int $userId
     * @param string $role
     * @return bool
     */
    public function addMember($projectId, $userId, $role = 'member')
    {
        // Check if the member already exists
        $existing = $this->db->fetch("
            SELECT * FROM project_members
            WHERE project_id = ? AND user_id = ?
        ", [$projectId, $userId]);
        
        if ($existing) {
            // Update the role if it's different
            if ($existing['role'] !== $role) {
                $this->db->query("
                    UPDATE project_members
                    SET role = ?
                    WHERE project_id = ? AND user_id = ?
                ", [$role, $projectId, $userId]);
            }
            
            return true;
        }
        
        // Add the new member
        $this->db->query("
            INSERT INTO project_members (project_id, user_id, role, created_at)
            VALUES (?, ?, ?, NOW())
        ", [$projectId, $userId, $role]);
        
        return true;
    }

    /**
     * Remove a member from a project.
     *
     * @param int $projectId
     * @param int $userId
     * @return bool
     */
    public function removeMember($projectId, $userId)
    {
        $this->db->query("
            DELETE FROM project_members
            WHERE project_id = ? AND user_id = ?
        ", [$projectId, $userId]);
        
        return true;
    }

    /**
     * Get project progress.
     *
     * @param int $projectId
     * @return float
     */
    public function getProgress($projectId)
    
    {
        $result = $this->db->fetch("
            SELECT 
                COUNT(*) as total_tasks,
                SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as completed_tasks
            FROM tasks
            WHERE project_id = ?
        ", [$projectId]);
        
        if (!$result || $result['total_tasks'] == 0) {
            return 0;
        }
        
        return ($result['completed_tasks'] / $result['total_tasks']) * 100;
    }
}

/**
 * Get task statistics for each project.
 *
 * @param int $userId
 * @return array
 */
    /**
     * Get task statistics for each project.
     *
     * @param int $userId
     * @return array
     */
    public function getStatistics($userId)
{
    return $this->db->fetchAll("
        SELECT p.id, p.name,
            (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as total_tasks,
            (SELECT COUNT(*) FROM tasks WHERE project_id = p.id AND status = 'done') as completed_tasks
        FROM projects p
        WHERE p.owner_id = ? OR p.id IN (
            SELECT project_id FROM project_members WHERE user_id = ?
        )
    ", [$userId, $userId]);
}
