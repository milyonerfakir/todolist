<?php

namespace App\Models;

use App\Core\Database;

class Search
{
    /**
     * The database instance.
     *
     * @var \App\Core\Database
     */
    protected $db;

    /**
     * Create a new Search instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Search across all entities.
     *
     * @param string $query
     * @param int|null $userId
     * @return array
     */
    public function search($query, $userId = null)
    {
        $results = [
            'projects' => $this->searchProjects($query, $userId),
            'tasks' => $this->searchTasks($query, $userId),
            'events' => $this->searchEvents($query, $userId),
        ];
        
        return $results;
    }

    /**
     * Search projects.
     *
     * @param string $query
     * @param int|null $userId
     * @return array
     */
    public function searchProjects($query, $userId = null)
    {
        $searchTerm = "%$query%";
        
        $sql = "
            SELECT p.*, u.name as owner_name
            FROM projects p
            LEFT JOIN users u ON p.owner_id = u.id
            WHERE (p.name LIKE ? OR p.description LIKE ?)
        ";
        
        $params = [$searchTerm, $searchTerm];
        
        if ($userId) {
            $sql .= " AND (p.owner_id = ? OR p.id IN (SELECT project_id FROM project_members WHERE user_id = ?))";
            $params[] = $userId;
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY p.name LIMIT 10";
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Search tasks.
     *
     * @param string $query
     * @param int|null $userId
     * @return array
     */
    public function searchTasks($query, $userId = null)
    {
        $searchTerm = "%$query%";
        
        $sql = "
            SELECT t.*, p.name as project_name, u.name as assigned_to_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            LEFT JOIN users u ON t.assigned_to = u.id
            WHERE (t.title LIKE ? OR t.description LIKE ?)
        ";
        
        $params = [$searchTerm, $searchTerm];
        
        if ($userId) {
            $sql .= " AND (t.assigned_to = ? OR t.created_by = ?)";
            $params[] = $userId;
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY t.due_date ASC, t.priority DESC LIMIT 10";
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Search calendar events.
     *
     * @param string $query
     * @param int|null $userId
     * @return array
     */
    public function searchEvents($query, $userId = null)
    {
        $searchTerm = "%$query%";
        
        $sql = "
            SELECT e.*, u.name as created_by_name
            FROM calendar_events e
            LEFT JOIN users u ON e.created_by = u.id
            WHERE (e.title LIKE ? OR e.description LIKE ? OR e.location LIKE ?)
        ";
        
        $params = [$searchTerm, $searchTerm, $searchTerm];
        
        if ($userId) {
            $sql .= " AND (e.created_by = ? OR e.id IN (SELECT event_id FROM event_attendees WHERE user_id = ?))";
            $params[] = $userId;
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY e.start_date ASC LIMIT 10";
        
        return $this->db->fetchAll($sql, $params);
    }
}