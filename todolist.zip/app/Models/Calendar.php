<?php

namespace App\Models;

use App\Core\Database;

class Calendar
{
    /**
     * The database instance.
     *
     * @var \App\Core\Database
     */
    protected $db;

    /**
     * Create a new Calendar instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Get all events.
     *
     * @param int|null $userId
     * @return array
     */
    public function getEvents($userId = null)
    {
        $sql = "
            SELECT e.*, u.name as created_by_name
            FROM calendar_events e
            LEFT JOIN users u ON e.created_by = u.id
        ";
        
        $params = [];
        
        if ($userId) {
            $sql .= " WHERE e.created_by = ? OR e.id IN (SELECT event_id FROM event_attendees WHERE user_id = ?)";
            $params = [$userId, $userId];
        }
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get events for a specific date range.
     *
     * @param string $start
     * @param string $end
     * @param int|null $userId
     * @return array
     */
    public function getEventsForRange($start, $end, $userId = null)
    {
        $sql = "
            SELECT e.*, u.name as created_by_name
            FROM calendar_events e
            LEFT JOIN users u ON e.created_by = u.id
            WHERE (e.start_date BETWEEN ? AND ? OR e.end_date BETWEEN ? AND ?)
        ";
        
        $params = [$start, $end, $start, $end];
        
        if ($userId) {
            $sql .= " AND (e.created_by = ? OR e.id IN (SELECT event_id FROM event_attendees WHERE user_id = ?))";
            $params[] = $userId;
            $params[] = $userId;
        }
        
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Find an event by ID.
     *
     * @param int $id
     * @return array|null
     */
    public function find($id)
    {
        return $this->db->fetch("
            SELECT e.*, u.name as created_by_name
            FROM calendar_events e
            LEFT JOIN users u ON e.created_by = u.id
            WHERE e.id = ?
        ", [$id]);
    }

    /**
     * Create a new event.
     *
     * @param array $data
     * @return int|bool
     */
    public function create($data)
    {
        $sql = "INSERT INTO calendar_events (title, description, start_date, end_date, all_day, location, color, created_by, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $params = [
            $data['title'],
            $data['description'] ?? null,
            $data['start_date'],
            $data['end_date'],
            $data['all_day'] ?? 0,
            $data['location'] ?? null,
            $data['color'] ?? '#3B82F6',
            $data['created_by'],
        ];
        
        $this->db->query($sql, $params);
        $eventId = $this->db->lastInsertId();
        
        // Add attendees if provided
        if (isset($data['attendees']) && is_array($data['attendees'])) {
            foreach ($data['attendees'] as $userId) {
                $this->addAttendee($eventId, $userId);
            }
        }
        
        return $eventId;
    }

    /**
     * Update an event.
     *
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data)
    {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if ($key !== 'id' && $key !== 'attendees') {
                $fields[] = "$key = ?";
                $params[] = $value;
            }
        }
        
        $params[] = $id;
        
        $sql = "UPDATE calendar_events SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
        
        $this->db->query($sql, $params);
        
        // Update attendees if provided
        if (isset($data['attendees']) && is_array($data['attendees'])) {
            // Remove all existing attendees
            $this->db->query("DELETE FROM event_attendees WHERE event_id = ?", [$id]);
            
            // Add new attendees
            foreach ($data['attendees'] as $userId) {
                $this->addAttendee($id, $userId);
            }
        }
        
        return true;
    }

    /**
     * Delete an event.
     *
     * @param int $id
     * @return bool
     */
    public function delete($id)
    {
        // First delete all attendees
        $this->db->query("DELETE FROM event_attendees WHERE event_id = ?", [$id]);
        
        // Then delete the event
        $this->db->query("DELETE FROM calendar_events WHERE id = ?", [$id]);
        
        return true;
    }

    /**
     * Move an event (update dates).
     *
     * @param int $id
     * @param string $start
     * @param string $end
     * @return bool
     */
    public function moveEvent($id, $start, $end)
    {
        $this->db->query("
            UPDATE calendar_events
            SET start_date = ?, end_date = ?, updated_at = NOW()
            WHERE id = ?
        ", [$start, $end, $id]);
        
        return true;
    }

    /**
     * Add an attendee to an event.
     *
     * @param int $eventId
     * @param int $userId
     * @return bool
     */
    public function addAttendee($eventId, $userId)
    {
        $this->db->query("
            INSERT INTO event_attendees (event_id, user_id, created_at)
            VALUES (?, ?, NOW())
        ", [$eventId, $userId]);
        
        return true;
    }

    /**
     * Remove an attendee from an event.
     *
     * @param int $eventId
     * @param int $userId
     * @return bool
     */
    public function removeAttendee($eventId, $userId)
    {
        $this->db->query("
            DELETE FROM event_attendees
            WHERE event_id = ? AND user_id = ?
        ", [$eventId, $userId]);
        
        return true;
    }

    /**
     * Get attendees for an event.
     *
     * @param int $eventId
     * @return array
     */
    public function getAttendees($eventId)
    {
        return $this->db->fetchAll("
            SELECT u.id, u.name, u.email
            FROM event_attendees ea
            JOIN users u ON ea.user_id = u.id
            WHERE ea.event_id = ?
            ORDER BY u.name
        ", [$eventId]);
    }
}