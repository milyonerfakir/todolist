<?php

namespace App\Core;

class View
{
    /**
     * The base path for views.
     *
     * @var string
     */
    protected $viewPath = __DIR__ . '/../../views/';

    /**
     * The base path for layouts.
     *
     * @var string
     */
    protected $layoutPath = __DIR__ . '/../../views/layouts/';

    /**
     * The default layout.
     *
     * @var string
     */
    protected $layout = 'app';

    /**
     * Render a view.
     *
     * @param string $view
     * @param array $data
     * @return string
     */
    public function render($view, $data = [])
    {
        $viewContent = $this->renderView($view, $data);
        $layoutContent = $this->renderLayout($data);
        
        return str_replace('{{content}}', $viewContent, $layoutContent);
    }

    /**
     * Render a view without a layout.
     *
     * @param string $view
     * @param array $data
     * @return string
     */
    public function renderOnly($view, $data = [])
    {
        return $this->renderView($view, $data);
    }

    /**
     * Set the layout.
     *
     * @param string $layout
     * @return $this
     */
    public function setLayout($layout)
    {
        $this->layout = $layout;
        return $this;
    }

    /**
     * Render the view.
     *
     * @param string $view
     * @param array $data
     * @return string
     */
    protected function renderView($view, $data)
    {
        foreach ($data as $key => $value) {
            $$key = $value;
        }
        
        ob_start();
        include $this->viewPath . $view . '.php';
        return ob_get_clean();
    }

    /**
     * Render the layout.
     *
     * @param array $data
     * @return string
     */
    protected function renderLayout($data)
    {
        foreach ($data as $key => $value) {
            $$key = $value;
        }
        
        ob_start();
        include $this->layoutPath . $this->layout . '.php';
        return ob_get_clean();
    }
}