<?php

namespace App\Core;

class Response
{
    /**
     * Set the response status code.
     *
     * @param int $code
     * @return $this
     */
    public function status($code)
    {
        http_response_code($code);
        return $this;
    }

    /**
     * Set a response header.
     *
     * @param string $name
     * @param string $value
     * @return $this
     */
    public function header($name, $value)
    {
        header("$name: $value");
        return $this;
    }

    /**
     * Set JSON content type header.
     *
     * @return $this
     */
    public function json()
    {
        return $this->header('Content-Type', 'application/json');
    }

    /**
     * Redirect to a given URL.
     *
     * @param string $url
     * @param int $statusCode
     * @return void
     */
    public function redirect($url, $statusCode = 302)
    {
        $this->status($statusCode);
        header("Location: $url");
        exit;
    }

    /**
     * Return a JSON response.
     *
     * @param mixed $data
     * @param int $statusCode
     * @return void
     */
    public function jsonResponse($data, $statusCode = 200)
    {
        $this->status($statusCode)->json();
        echo json_encode($data);
        exit;
    }

    /**
     * Return a success JSON response.
     *
     * @param mixed $data
     * @param string $message
     * @param int $statusCode
     * @return void
     */
    public function success($data = null, $message = 'Success', $statusCode = 200)
    {
        return $this->jsonResponse([
            'success' => true,
            'message' => $message,
            'data' => $data
        ], $statusCode);
    }

    /**
     * Return an error JSON response.
     *
     * @param string $message
     * @param int $statusCode
     * @param mixed $errors
     * @return void
     */
    public function error($message = 'Error', $statusCode = 400, $errors = null)
    {
        return $this->jsonResponse([
            'success' => false,
            'message' => $message,
            'errors' => $errors
        ], $statusCode);
    }

    /**
     * Return a view response.
     *
     * @param string $view
     * @param array $data
     * @return void
     */
    public function view($view, $data = [])
    {
        $viewInstance = new View();
        echo $viewInstance->render($view, $data);
        exit;
    }
}