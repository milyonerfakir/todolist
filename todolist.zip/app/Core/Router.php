<?php

namespace App\Core;

class Router
{
    /**
     * The request instance.
     *
     * @var \App\Core\Request
     */
    protected $request;

    /**
     * The response instance.
     *
     * @var \App\Core\Response
     */
    protected $response;

    /**
     * The registered routes.
     *
     * @var array
     */
    protected $routes = [];

    /**
     * Create a new router instance.
     *
     * @param \App\Core\Request $request
     * @param \App\Core\Response $response
     * @return void
     */
    public function __construct(Request $request, Response $response)
    {
        $this->request = $request;
        $this->response = $response;
    }

    /**
     * Register a GET route.
     *
     * @param string $path
     * @param mixed $callback
     * @return void
     */
    public function get($path, $callback)
    {
        $this->routes['GET'][$path] = $callback;
    }

    /**
     * Register a POST route.
     *
     * @param string $path
     * @param mixed $callback
     * @return void
     */
    public function post($path, $callback)
    {
        $this->routes['POST'][$path] = $callback;
    }

    /**
     * Register a PUT route.
     *
     * @param string $path
     * @param mixed $callback
     * @return void
     */
    public function put($path, $callback)
    {
        $this->routes['PUT'][$path] = $callback;
    }

    /**
     * Register a DELETE route.
     *
     * @param string $path
     * @param mixed $callback
     * @return void
     */
    public function delete($path, $callback)
    {
        $this->routes['DELETE'][$path] = $callback;
    }

    /**
     * Resolve the current route.
     *
     * @return mixed
     */
    public function resolve()
    {
        $method = $this->request->method();
        $path = $this->request->path();
        
        // Remove trailing slash if not root path
        if ($path !== '/' && substr($path, -1) === '/') {
            $path = rtrim($path, '/');
        }
        
        $callback = $this->routes[$method][$path] ?? false;
        
        if ($callback === false) {
            $this->response->status(404);
            return $this->response->view('errors/404');
        }
        
        if (is_string($callback)) {
            return $this->response->view($callback);
        }
        
        if (is_array($callback)) {
            $controller = new $callback[0]();
            $callback[0] = $controller;
        }
        
        return call_user_func($callback, $this->request, $this->response);
    }
}