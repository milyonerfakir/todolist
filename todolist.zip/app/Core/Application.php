<?php

namespace App\Core;

class Application
{
    /**
     * The application instance.
     *
     * @var \App\Core\Application
     */
    protected static $instance;

    /**
     * The router instance.
     *
     * @var \App\Core\Router
     */
    protected $router;

    /**
     * The request instance.
     *
     * @var \App\Core\Request
     */
    protected $request;

    /**
     * The response instance.
     *
     * @var \App\Core\Response
     */
    protected $response;

    /**
     * The database instance.
     *
     * @var \App\Core\Database
     */
    protected $database;

    /**
     * Create a new application instance.
     *
     * @return void
     */
    public function __construct()
    {
        static::$instance = $this;
        
        $this->request = new Request();
        $this->response = new Response();
        $this->router = new Router($this->request, $this->response);
        $this->database = new Database();
        
        $this->loadRoutes();
    }

    /**
     * Get the application instance.
     *
     * @return \App\Core\Application
     */
    public static function getInstance()
    {
        return static::$instance;
    }

    /**
     * Get the router instance.
     *
     * @return \App\Core\Router
     */
    public function getRouter()
    {
        return $this->router;
    }

    /**
     * Get the request instance.
     *
     * @return \App\Core\Request
     */
    public function getRequest()
    {
        return $this->request;
    }

    /**
     * Get the response instance.
     *
     * @return \App\Core\Response
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * Get the database instance.
     *
     * @return \App\Core\Database
     */
    public function getDatabase()
    {
        return $this->database;
    }

    /**
     * Load the routes for the application.
     *
     * @return void
     */
    protected function loadRoutes()
    {
        require_once __DIR__ . '/../../routes/web.php';
        require_once __DIR__ . '/../../routes/api.php';
    }

    /**
     * Run the application.
     *
     * @return void
     */
    public function run()
    {
        $this->router->resolve();
    }
}