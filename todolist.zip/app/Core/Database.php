<?php

namespace App\Core;

use PDO;
use PDOException;

class Database
{
    /**
     * The PDO instance.
     *
     * @var \PDO
     */
    protected $pdo;

    /**
     * Create a new database instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->connect();
    }

    /**
     * Connect to the database.
     *
     * @return void
     */
    protected function connect()
    {
        try {
            // Sunucu ortamında mı çalışıyoruz kontrol edelim
            $isProduction = strpos($_SERVER['HTTP_HOST'] ?? '', 'etiklife.com') !== false;
            
            if ($isProduction) {
                // Sunucu ortamı için bağlantı bilgileri
                $host = 'localhost';
                $port = '3306';
                $database = 'todolist';
                $username = 'todolist';
                $password = 'zoAd6KGz=6H9';
            } else {
                // Yerel geliştirme ortamı için bağlantı bilgileri
                $host = $_ENV['DB_HOST'] ?? 'localhost';
                $port = $_ENV['DB_PORT'] ?? '3306';
                $database = $_ENV['DB_DATABASE'] ?? 'todolist';
                $username = $_ENV['DB_USERNAME'] ?? 'todolist';
                $password = $_ENV['DB_PASSWORD'] ?? 'zoAd6KGz=6H9';
            }
            
            $dsn = "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4";
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $this->pdo = new PDO($dsn, $username, $password, $options);
        } catch (PDOException $e) {
            // Log the error but don't expose details in production
            error_log("Database connection failed: " . $e->getMessage());
            
            if (getenv('APP_ENV') !== 'production') {
                throw $e;
            } else {
                // In production, show a generic error
                die("Database connection error. Please try again later.");
            }
        }
    }

    /**
     * Execute a query.
     *
     * @param string $sql
     * @param array $params
     * @return \PDOStatement
     */
    public function query($sql, $params = [])
    {
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute($params);
            return $statement;
        } catch (PDOException $e) {
            error_log("Query failed: " . $e->getMessage());
            
            if (getenv('APP_ENV') !== 'production') {
                throw $e;
            } else {
                // In production, show a generic error
                die("Database query error. Please try again later.");
            }
        }
    }

    /**
     * Get a single record.
     *
     * @param string $sql
     * @param array $params
     * @return mixed
     */
    public function fetch($sql, $params = [])
    {
        return $this->query($sql, $params)->fetch();
    }

    /**
     * Get multiple records.
     *
     * @param string $sql
     * @param array $params
     * @return array
     */
    public function fetchAll($sql, $params = [])
    {
        return $this->query($sql, $params)->fetchAll();
    }

    /**
     * Get the last inserted ID.
     *
     * @return string
     */
    public function lastInsertId()
    {
        return $this->pdo->lastInsertId();
    }
}