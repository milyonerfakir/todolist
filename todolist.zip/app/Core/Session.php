<?php

namespace App\Core;

class Session
{
    /**
     * Start the session.
     *
     * @return void
     */
    public static function start()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Set a session value.
     *
     * @param string $key
     * @param mixed $value
     * @return void
     */
    public static function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }

    /**
     * Get a session value.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function get($key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }

    /**
     * Check if a session key exists.
     *
     * @param string $key
     * @return bool
     */
    public static function has($key)
    {
        return isset($_SESSION[$key]);
    }

    /**
     * Remove a session key.
     *
     * @param string $key
     * @return void
     */
    public static function remove($key)
    {
        unset($_SESSION[$key]);
    }

    /**
     * Get and remove a session value.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function flash($key, $default = null)
    {
        $value = static::get($key, $default);
        static::remove($key);
        return $value;
    }

    /**
     * Set a flash message.
     *
     * @param string $key
     * @param mixed $value
     * @return void
     */
    public static function setFlash($key, $value)
    {
        $_SESSION['_flash'][$key] = $value;
    }

    /**
     * Get a flash message.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function getFlash($key, $default = null)
    {
        return $_SESSION['_flash'][$key] ?? $default;
    }

    /**
     * Clear all flash messages.
     *
     * @return void
     */
    public static function clearFlash()
    {
        unset($_SESSION['_flash']);
    }

    /**
     * Destroy the session.
     *
     * @return void
     */
    public static function destroy()
    {
        session_destroy();
    }
}